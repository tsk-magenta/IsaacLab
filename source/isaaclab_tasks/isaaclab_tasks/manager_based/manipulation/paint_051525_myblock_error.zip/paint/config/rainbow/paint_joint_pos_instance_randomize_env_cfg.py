# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

import torch

import isaaclab.sim as sim_utils
from isaaclab.assets import RigidObjectCfg, RigidObjectCollectionCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import CameraCfg, FrameTransformerCfg
from isaaclab.sensors.frame_transformer.frame_transformer_cfg import OffsetCfg
from isaaclab.sim.schemas.schemas_cfg import RigidBodyPropertiesCfg
from isaaclab.sim.spawners.from_files.from_files_cfg import UsdFileCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.envs.mdp.actions.actions_cfg import JointPositionActionCfg, BinaryJointPositionActionCfg

from isaaclab_tasks.manager_based.manipulation.paint import mdp
from isaaclab_tasks.manager_based.manipulation.paint.mdp import franka_paint_events as rainbow_paint_events
from isaaclab_tasks.manager_based.manipulation.paint.paint_instance_randomize_env_cfg import (
    PaintInstanceRandomizeEnvCfg,
)

##
# Pre-defined configs
##
from isaaclab.markers.config import FRAME_MARKER_CFG  # isort: skip
from isaaclab_assets.robots.rainbow import RB1300_CFG  # isort: skip


@configclass
class EventCfg:
    """Configuration for events."""

    init_rainbow_arm_pose = EventTerm(
        func=rainbow_paint_events.set_default_joint_pose,
        mode="startup",
        params={
            # Updated for 6-joint Rainbow robot - base, shoulder, elbow, wrist1, wrist2, wrist3
            "default_pose": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        },
    )

    randomize_rainbow_joint_state = EventTerm(
        func=rainbow_paint_events.randomize_joint_by_gaussian_offset,
        mode="reset",
        params={
            "mean": 0.0,
            "std": 0.02,
            "asset_cfg": SceneEntityCfg("robot"),
        },
    )

    randomize_cubes_in_focus = EventTerm(
        func=rainbow_paint_events.randomize_rigid_objects_in_focus,
        mode="reset",
        params={
            "asset_cfgs": [SceneEntityCfg("cube_1"), SceneEntityCfg("cube_2"), SceneEntityCfg("cube_3")],
            "out_focus_state": torch.tensor([10.0, 10.0, 10.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]),
            "pose_range": {"x": (0.4, 0.6), "y": (-0.10, 0.10), "z": (0.0203, 0.0203), "yaw": (-1.0, 1, 0)},
            "min_separation": 0.1,
        },
    )


@configclass
class RainbowPaintInstanceRandomizeEnvCfg(PaintInstanceRandomizeEnvCfg):
    def __post_init__(self):
        # post init of parent
        super().__post_init__()

        # Set events
        self.events = EventCfg()

        # Set Rainbow as robot
        self.scene.robot = RB1300_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")

        # Reduce the number of environments due to camera resources
        self.scene.num_envs = 2

        # Set actions for the specific robot type (Rainbow)
        self.actions.arm_action = JointPositionActionCfg(
            asset_name="robot", joint_names=["wrist[1-3]"], scale=0.5, use_default_offset=True
        )
        
        # Rainbow doesn't have gripper, so set to None
        self.actions.gripper_action = None

        # Rigid body properties of each cube
        cube_properties = RigidBodyPropertiesCfg(
            solver_position_iteration_count=16,
            solver_velocity_iteration_count=1,
            max_angular_velocity=1000.0,
            max_linear_velocity=1000.0,
            max_depenetration_velocity=5.0,
            disable_gravity=False,
        )

        # Set each stacking cube to be a collection of rigid objects
        cube_1_config_dict = {
            "blue_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_1_Blue",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.4, 0.0, 0.0203], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/blue_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
            "red_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_1_Red",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.4, 0.0, 0.0403], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/red_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
        }

        cube_2_config_dict = {
            "red_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_2_Red",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.55, 0.05, 0.0203], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/red_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
            "yellow_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_2_Yellow",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.55, 0.05, 0.0403], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/yellow_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
        }

        cube_3_config_dict = {
            "yellow_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_3_Yellow",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.60, -0.1, 0.0203], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/yellow_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
            "green_cube": RigidObjectCfg(
                prim_path="{ENV_REGEX_NS}/Cube_2_Green",
                init_state=RigidObjectCfg.InitialStateCfg(pos=[0.60, -0.1, 0.0403], rot=[1, 0, 0, 0]),
                spawn=UsdFileCfg(
                    usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/green_block.usd",
                    scale=(1.0, 1.0, 1.0),
                    rigid_props=cube_properties,
                ),
            ),
        }

        self.scene.cube_1 = RigidObjectCollectionCfg(rigid_objects=cube_1_config_dict)
        self.scene.cube_2 = RigidObjectCollectionCfg(rigid_objects=cube_2_config_dict)
        self.scene.cube_3 = RigidObjectCollectionCfg(rigid_objects=cube_3_config_dict)

        # Set wrist camera
        self.scene.wrist_cam = CameraCfg(
            prim_path="{ENV_REGEX_NS}/Robot/wrist3/wrist_cam",
            update_period=0.0333,
            height=84,
            width=84,
            data_types=["rgb", "distance_to_image_plane"],
            spawn=sim_utils.PinholeCameraCfg(
                focal_length=24.0, focus_distance=400.0, horizontal_aperture=20.955, clipping_range=(0.1, 1.0e5)
            ),
            offset=CameraCfg.OffsetCfg(pos=(0.025, 0.0, 0.0), rot=(0.707, 0.0, 0.0, 0.707), convention="ros"),
        )

        # Set table view camera
        self.scene.table_cam = CameraCfg(
            prim_path="{ENV_REGEX_NS}/table_cam",
            update_period=0.0333,
            height=84,
            width=84,
            data_types=["rgb", "distance_to_image_plane"],
            spawn=sim_utils.PinholeCameraCfg(
                focal_length=24.0, focus_distance=400.0, horizontal_aperture=20.955, clipping_range=(0.1, 1.0e5)
            ),
            offset=CameraCfg.OffsetCfg(pos=(1.0, 0.0, 0.33), rot=(-0.3799, 0.5963, 0.5963, -0.3799), convention="ros"),
        )

        # Listens to the required transforms
        marker_cfg = FRAME_MARKER_CFG.copy()
        marker_cfg.markers["frame"].scale = (0.1, 0.1, 0.1)
        marker_cfg.prim_path = "/Visuals/FrameTransformer"
        self.scene.ee_frame = FrameTransformerCfg(
            prim_path="{ENV_REGEX_NS}/Robot/base",
            debug_vis=False,
            visualizer_cfg=marker_cfg,
            target_frames=[
                FrameTransformerCfg.FrameCfg(
                    prim_path="{ENV_REGEX_NS}/Robot/wrist3",
                    name="end_effector",
                    offset=OffsetCfg(
                        pos=[0.0, 0.0, 0.05],
                    ),
                ),
                # Rainbow doesn't have gripper fingers
            ],
        )
