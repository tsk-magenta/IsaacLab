# my_block_ik_rel_env_cfg.py (상속 활용 방식)

from isaaclab.utils import configclass
# 필요한 컨트롤러, 액션, 로봇 설정 등 임포트
from isaaclab.controllers.differential_ik_cfg import DifferentialIKControllerCfg
from isaaclab.envs.mdp.actions.actions_cfg import DifferentialInverseKinematicsActionCfg
from isaaclab_assets.robots.rainbow import RB1300_HIGH_PD_CFG
# 수정된 부모 설정 파일을 임포트
from . import paint_joint_pos_env_cfg # MyBlock 추가, 큐브 주석처리된 버전

# --- 중요: 부모 클래스로 'paint_joint_pos_env_cfg.RainbowPaintEnvCfg' 지정 ---
@configclass
class MyBlockIKRelEnvCfg(paint_joint_pos_env_cfg.RainbowPaintEnvCfg):
    """Configuration for the Rainbow MyBlock environment using inheritance."""

    def __post_init__(self):
        # --- 1. 부모 클래스의 __post_init__ 호출 (필수) ---
        # 이렇게 하면 부모 파일에서 정의된 Scene (MyBlock, 테이블, 조명, ee_frame 등),
        # Observations, Terminations, Events 등이 로드됩니다.
        super().__post_init__()

        # --- 2. 변경/덮어쓸 부분만 정의 ---

        # 로봇 설정을 HIGH_PD 버전으로 변경
        self.scene.robot = RB1300_HIGH_PD_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")

        # 팔 액션을 IK 방식으로 변경
        self.actions.arm_action = DifferentialInverseKinematicsActionCfg(
            asset_name="robot",
            joint_names=["wrist[1-3]"],
            body_name="wrist3",
            controller=DifferentialIKControllerCfg(command_type="pose", use_relative_mode=True, ik_method="dls"),
            scale=0.5,
            body_offset=DifferentialInverseKinematicsActionCfg.OffsetCfg(pos=[0.0, 0.0, 0.05]),
        )

        # 그리퍼 액션은 Rainbow에는 없으므로 제거
        # Rainbow 로봇은 그리퍼가 없으므로 해당 부분 주석 처리 또는 제거

        # Observation, Termination, Event 등도 필요하다면 여기서 덮어쓰거나 수정 가능
        # 예: self.observations.policy.my_new_obs = ObsTerm(...)
        # 예: self.terminations.my_new_termination = DoneTerm(...)
