# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
import gymnasium as gym
import os

from . import (
    agents,
    paint_ik_abs_env_cfg,
    paint_ik_rel_blueprint_env_cfg,
    paint_ik_rel_env_cfg,
    paint_ik_rel_instance_randomize_env_cfg,
    paint_ik_rel_visuomotor_env_cfg,
    paint_joint_pos_env_cfg,
    paint_joint_pos_instance_randomize_env_cfg,
    my_block_ik_rel_env_cfg,
    rainbow_paint_custom_env,
)

##
# Register Gym environments.
##

##
# Joint Position Control
##

gym.register(
    id="Isaac-Paint-Rainbow-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_joint_pos_env_cfg.RainbowPaintEnvCfg,
    },
    disable_env_checker=True,
)

gym.register(
    id="Isaac-Paint-Instance-Randomize-Rainbow-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_joint_pos_instance_randomize_env_cfg.RainbowPaintInstanceRandomizeEnvCfg,
    },
    disable_env_checker=True,
)


##
# Inverse Kinematics - Relative Pose Control
##



################### 새로운 환경 등록 ###################
# gym.register(
#     id="Isaac-Paint-Cube-Rainbow-IK-Rel-v0",
#     entry_point="isaaclab.envs:ManagerBasedRLEnv",
#     kwargs={
#         "env_cfg_entry_point": stack_ik_rel_env_cfg.RainbowCubeStackEnvCfg,
#         "robomimic_bc_cfg_entry_point": os.path.join(agents.__path__[0], "robomimic/bc_rnn_low_dim.json"),
#     },
#     disable_env_checker=True,
# )

gym.register(
    id="Isaac-Paint-Rainbow-IK-Rel-v0",
    # --- entry_point 변경 ---
    # 형식: "패키지.경로.파일명:클래스명"
    # isaaclab_tasks.manager_based.manipulation.stack 이 기본 경로라고 가정
    entry_point="isaaclab_tasks.manager_based.manipulation.paint.config.rainbow.rainbow_paint_custom_env:RainbowPaintCustomEnv",
    kwargs={
        "env_cfg_entry_point": my_block_ik_rel_env_cfg.MyBlockIKRelEnvCfg,
        "robomimic_bc_cfg_entry_point": os.path.join(agents.__path__[0], "robomimic/bc_rnn_low_dim.json"),
    },
    disable_env_checker=True,
)
######################################################



gym.register(
    id="Isaac-Paint-Rainbow-IK-Rel-Visuomotor-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_ik_rel_visuomotor_env_cfg.RainbowPaintVisuomotorEnvCfg,
        "robomimic_bc_cfg_entry_point": os.path.join(agents.__path__[0], "robomimic/bc_rnn_image_84.json"),
    },
    disable_env_checker=True,
)

gym.register(
    id="Isaac-Paint-Rainbow-IK-Abs-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_ik_abs_env_cfg.RainbowPaintEnvCfg,
        "robomimic_bc_cfg_entry_point": os.path.join(agents.__path__[0], "robomimic/bc_rnn_low_dim.json"),
    },
    disable_env_checker=True,
)

gym.register(
    id="Isaac-Paint-Instance-Randomize-Rainbow-IK-Rel-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_ik_rel_instance_randomize_env_cfg.RainbowPaintInstanceRandomizeEnvCfg,
    },
    disable_env_checker=True,
)

gym.register(
    id="Isaac-Paint-Rainbow-IK-Rel-Blueprint-v0",
    entry_point="isaaclab.envs:ManagerBasedRLEnv",
    kwargs={
        "env_cfg_entry_point": paint_ik_rel_blueprint_env_cfg.RainbowPaintBlueprintEnvCfg,
    },
    disable_env_checker=True,
)
