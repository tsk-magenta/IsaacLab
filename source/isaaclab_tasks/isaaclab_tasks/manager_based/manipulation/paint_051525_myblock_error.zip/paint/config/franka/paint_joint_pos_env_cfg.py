# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

from isaaclab.assets import RigidObjectCfg, AssetBaseCfg
from isaaclab.managers import EventTermCfg as EventTerm
from isaaclab.managers import SceneEntityCfg
from isaaclab.sensors import FrameTransformerCfg
from isaaclab.sensors.frame_transformer.frame_transformer_cfg import OffsetCfg
from isaaclab.sim.schemas.schemas_cfg import RigidBodyPropertiesCfg
from isaaclab.sim.spawners.from_files.from_files_cfg import UsdFileCfg
from isaaclab.utils import configclass
from isaaclab.utils.assets import ISAAC_NUCLEUS_DIR
from isaaclab.sim.spawners.lights.lights_cfg import DiskLightCfg, SphereLightCfg, DomeLightCfg
from isaaclab.envs.mdp.actions.actions_cfg import JointPositionActionCfg, BinaryJointPositionActionCfg

from isaaclab_tasks.manager_based.manipulation.paint import mdp
from isaaclab_tasks.manager_based.manipulation.paint.mdp import franka_paint_events
from isaaclab_tasks.manager_based.manipulation.paint.paint_env_cfg import PaintEnvCfg, target

##
# Pre-defined configs
##
from isaaclab.markers.config import FRAME_MARKER_CFG  # isort: skip
from isaaclab_assets.robots.franka import FRANKA_PANDA_CFG  # isort: skip

## 내가 추가한 modules
import os
import isaaclab.sim as sim_utils
from isaaclab.sensors import CameraCfg

@configclass
class EventCfg:
    """Configuration for events."""

    init_franka_arm_pose = EventTerm(
        func=franka_paint_events.set_default_joint_pose,
        mode="startup",
        params={
            "default_pose": [0.0444, -0.1894, -0.1107, -2.5148, 0.0044, 2.3775, 0.6952, 0.0400, 0.0400],
        },
    )

    randomize_franka_joint_state = EventTerm(
        func=franka_paint_events.randomize_joint_by_gaussian_offset,
        mode="reset",
        params={
            "mean": 0.0,
            "std": 0.02,
            "asset_cfg": SceneEntityCfg("robot"),
        },
    )

    # randomize_cube_positions = EventTerm(
    #     func=franka_paint_events.randomize_object_pose,
    #     mode="reset",
    #     params={
    #         "pose_range": {"x": (0.4, 0.6), "y": (-0.10, 0.10), "z": (0.0203, 0.0203), "yaw": (-1.0, 1, 0)},
    #         "min_separation": 0.1,
    #         "asset_cfgs": [SceneEntityCfg("cube_1"), SceneEntityCfg("cube_2"), SceneEntityCfg("cube_3")],
    #     },
    # )


@configclass
class FrankaPaintEnvCfg(PaintEnvCfg):
    def __post_init__(self):
        ##
        config_directory = os.path.dirname(__file__)
        my_block_usd_path = os.path.join(config_directory, "block_hys.usd")

        # post init of parent
        super().__post_init__()

        # Set events
        self.events = EventCfg()

        # Set Franka as robot
        self.scene.robot = FRANKA_PANDA_CFG.replace(prim_path="{ENV_REGEX_NS}/Robot")
        self.scene.robot.spawn.semantic_tags = [("class", "robot")]

        # Add semantics to table
        self.scene.table.spawn.semantic_tags = [("class", "table")]

        # Add semantics to ground
        self.scene.plane.semantic_tags = [("class", "ground")]

        # Set actions for the specific robot type (franka)
        self.actions.arm_action = JointPositionActionCfg(
            asset_name="robot", joint_names=["panda_joint.*"], scale=0.5, use_default_offset=True
        )
        self.actions.gripper_action = BinaryJointPositionActionCfg(
            asset_name="robot",
            joint_names=["panda_finger.*"],
            open_command_expr={"panda_finger_.*": 0.04},
            close_command_expr={"panda_finger_.*": 0.0},
        )
        
        # Rigid body properties for objects
        cube_properties = RigidBodyPropertiesCfg(
            solver_position_iteration_count=16,
            solver_velocity_iteration_count=1,
            max_angular_velocity=1000.0,
            max_linear_velocity=1000.0,
            max_depenetration_velocity=5.0,
            disable_gravity=False,
        )
        
        # MyBlock configuration for better visibility
        self.scene.myblock = RigidObjectCfg(
            prim_path="{ENV_REGEX_NS}/MyBlock",
            init_state=RigidObjectCfg.InitialStateCfg(pos=[0.6, 0, 0.3], rot=[0.707, 0, 0, -0.707]),
            spawn=UsdFileCfg(
                usd_path=f"{ISAAC_NUCLEUS_DIR}/Props/Blocks/red_block.usd",
                scale=(1.5, 1.5, 0.5),  # Make it more visible
                rigid_props=cube_properties,
                semantic_tags=[("class", "myblock")],
            ),
        )
        
        # Add a point light for better block visibility
        self.scene.block_light = AssetBaseCfg(
            prim_path="{ENV_REGEX_NS}/BlockLight",
            init_state=AssetBaseCfg.InitialStateCfg(pos=[0.6, 0, 0.5]),  # Position right above the block
            spawn=SphereLightCfg(
                color=(1.0, 0.7, 0.7),  # Reddish light to match block
                intensity=10000.0,      # Very bright
                radius=0.05,           # Small radius
                treat_as_point=True    # Treat as point light
            ),
        )
        
        # Add a disk light for additional illumination
        self.scene.spotlight = AssetBaseCfg(
            prim_path="{ENV_REGEX_NS}/DiskLight",
            init_state=AssetBaseCfg.InitialStateCfg(pos=[0.6, 0, 1.0], rot=[1, 0, 0, 0]),  # Position above the block
            spawn=DiskLightCfg(
                color=(1.0, 1.0, 1.0),  # White light
                intensity=15000.0,      # Strong light
                radius=0.1,             # Small radius for focused light
            ),
        )

        # Camera configuration
        self.scene.table_camera = CameraCfg(
            # 카메라 Prim이 생성될 경로 (환경 네임스페이스 아래에 생성)
            prim_path="{ENV_REGEX_NS}/table_camera",
            # 카메라 업데이트 주기 (0이면 매 렌더링 스텝)
            update_period=0.0, # 필요에 따라 조정 (예: 0.0333 -> ~30Hz)
            # 카메라 해상도
            height=480,
            width=640,
            # 수집할 데이터 종류 (rgb, depth 등 추가 가능)
            data_types=["rgb"],
            # 카메라 내부 속성 설정 (Pinhole 카메라 사용)
            spawn=sim_utils.PinholeCameraCfg(
                focal_length=24.0,
                focus_distance=400.0,
                horizontal_aperture=20.955,
                clipping_range=(0.1, 1.0e5), # 물체가 보이는 최소/최대 거리
            ),
            # --- 카메라 위치 및 방향 설정 ---
            offset=CameraCfg.OffsetCfg(
                # prim_path 기준으로 상대적 위치 [X, Y, Z] (월드 좌표계 기준)
                # pos=(-3, -2.5, 4), # 예시: 테이블 중앙 위쪽
                pos=(-2, 1.56203, 1.32506), # 예시: 테이블 중앙 위쪽
                # prim_path 기준으로 상대적 회전 [w, x, y, z] (쿼터니언)
                # rot=(0.81215, 0.37003, -0.13992, -0.42885), # 예시: 아래를 약간 비스듬히 바라봄 
                rot=(-0.46447, -0.32107, 0.48129, 0.67047), # 예시: 아래를 약간 비스듬히 바라봄 

                convention="opengl", # 좌표계 관례 (보통 "ros" 또는 "opengl")
            ),
        )

        # Add a visual marker to highlight the target location on the block
        marker_cfg_target = FRAME_MARKER_CFG.copy()
        marker_cfg_target.markers["frame"].scale = (0.05, 0.05, 0.05)  # Smaller marker
        marker_cfg_target.prim_path = "/Visuals/TargetMarker"
        
        self.scene.target_marker = FrameTransformerCfg(
            prim_path="{ENV_REGEX_NS}/MyBlock",
            debug_vis=True,  # Enable visualization
            visualizer_cfg=marker_cfg_target,
            target_frames=[
                FrameTransformerCfg.FrameCfg(
                    prim_path="{ENV_REGEX_NS}/MyBlock",
                    name="target_point",
                    offset=OffsetCfg(
                        pos=target,  # Use the target position from the top of the file
                    ),
                ),
            ],
        )

        # Listens to the required transforms
        marker_cfg = FRAME_MARKER_CFG.copy()
        marker_cfg.markers["frame"].scale = (0.1, 0.1, 0.1)
        marker_cfg.prim_path = "/Visuals/FrameTransformer"
        self.scene.ee_frame = FrameTransformerCfg(
            prim_path="{ENV_REGEX_NS}/Robot/panda_link0",
            debug_vis=False,
            visualizer_cfg=marker_cfg,
            target_frames=[
                FrameTransformerCfg.FrameCfg(
                    prim_path="{ENV_REGEX_NS}/Robot/panda_hand",
                    name="end_effector",
                    offset=OffsetCfg(
                        pos=[0.0, 0.0, 0.1034],
                    ),
                ),
                FrameTransformerCfg.FrameCfg(
                    prim_path="{ENV_REGEX_NS}/Robot/panda_rightfinger",
                    name="tool_rightfinger",
                    offset=OffsetCfg(
                        pos=(0.0, 0.0, 0.046),
                    ),
                ),
                FrameTransformerCfg.FrameCfg(
                    prim_path="{ENV_REGEX_NS}/Robot/panda_leftfinger",
                    name="tool_leftfinger",
                    offset=OffsetCfg(
                        pos=(0.0, 0.0, 0.046),
                    ),
                ),
            ],
        )
