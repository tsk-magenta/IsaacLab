# franka_stack_custom_env.py 파일 내용

import torch
from isaaclab.envs import ManagerBasedRLEnv
from isaaclab.envs.manager_based_env_cfg import ManagerBasedEnvCfg # Cfg 타입 힌트용

class FrankaPaintCustomEnv(ManagerBasedRLEnv):
    """Custom environment class for Franka Paint task to store state."""

    # 타입을 명확히 하기 위해 cfg 타입을 지정해줄 수 있습니다 (선택 사항)
    cfg: ManagerBasedEnvCfg

    def __init__(self, cfg: ManagerBasedEnvCfg, **kwargs):
        """Initialize the environment and the counter."""
        # 부모 클래스 초기화 (필수)
        super().__init__(cfg=cfg, **kwargs)

        # --- 여기에 카운터 변수 초기화 ---
        # 디바이스와 환경 개수는 부모 클래스 초기화 후 접근 가능
        self.eef_near_target_counter = torch.zeros(self.num_envs, device=self.device, dtype=torch.int32)
        print(f"Initialized eef_near_target_counter on device {self.device} with shape {self.eef_near_target_counter.shape}")

    def _reset_idx(self, env_ids: torch.Tensor):
        """Reset the specified environment indices."""
        # 부모 클래스의 리셋 로직 호출 (필수)
        super()._reset_idx(env_ids)

        # --- 해당 환경들의 카운터 리셋 ---
        if hasattr(self, "eef_near_target_counter"):
            self.eef_near_target_counter[env_ids] = 0
        else:
             # 혹시 모르니 초기화 안됐으면 경고 (디버깅용)
             print("[Warning] Attempted to reset eef_near_target_counter before initialization.")

    # 필요하다면 여기에 다른 커스텀 메소드 추가 가능
    # 예: _step(actions) 메소드를 오버라이드하여 매 스텝 특정 로직 수행
    # def _step(self, actions: torch.Tensor) -> Tuple[Dict[str, Tensor], Tensor, Tensor, Tensor, Dict[str, Any]]:
    #     # ... pre-step logic ...
    #     obs, rewards, terminated, truncated, info = super()._step(actions)
    #     # ... post-step logic ...
    #     return obs, rewards, terminated, truncated, info